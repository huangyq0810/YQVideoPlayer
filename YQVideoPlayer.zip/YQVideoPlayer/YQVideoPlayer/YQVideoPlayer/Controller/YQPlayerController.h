//
//  YQPlayerController.h
//  YQVideoPlayer
//
//  Created by admin on 22/8/18.
//  Copyright © 2018年 admin. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface YQPlayerController : UIViewController

- (id)initWithURL:(NSURL *)assetURL;

@end
